﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace $rootnamespace$.Configurations
{
    class $fileinputname$Configuration : IEntityTypeConfiguration<$fileinputname$>
    {
        public void Configure(EntityTypeBuilder<$fileinputname$> builder)
        {
        }
    }
}
